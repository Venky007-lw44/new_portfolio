import type { Config } from "tailwindcss";

/**
 * Theme colors are driven by CSS variables (see src/app/globals.css) so the
 * dark theme (default) and the optional light theme share the same utilities.
 * Variables hold space-separated RGB channels, which keeps opacity modifiers
 * like `bg-accent/20` working.
 */
const withAlpha = (variable: string): string =>
  `rgb(var(${variable}) / <alpha-value>)`;

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: withAlpha("--background"), // #09090b
        surface: withAlpha("--surface"),
        border: withAlpha("--border"), // #27272a
        foreground: withAlpha("--foreground"),
        muted: withAlpha("--muted"),
        accent: {
          DEFAULT: withAlpha("--accent"), // violet
          2: withAlpha("--accent-2"), // cyan
        },
      },
      fontFamily: {
        sans: [
          "var(--font-geist-sans)",
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
        ],
        mono: [
          "var(--font-geist-mono)",
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "monospace",
        ],
      },
      boxShadow: {
        glow: "0 0 0 1px rgb(255 255 255 / 0.12) inset, 0 8px 24px -8px rgb(124 58 237 / 0.7)",
        "glow-lg":
          "0 0 0 1px rgb(255 255 255 / 0.2) inset, 0 14px 36px -6px rgb(124 58 237 / 0.85)",
      },
      keyframes: {
        float: {
          "0%": { transform: "translate3d(0, 0, 0)" },
          "100%": { transform: "translate3d(0, -28px, 0)" },
        },
      },
      animation: {
        float: "float 9s ease-in-out infinite alternate",
      },
    },
  },
  plugins: [],
};

export default config;
