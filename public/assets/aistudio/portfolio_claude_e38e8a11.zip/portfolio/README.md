# Developer Portfolio

Dark-first, editorial portfolio built with **Next.js (App Router)**, **Tailwind CSS**, **Framer Motion** and **Lucide React**.

## Getting started

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # production build (runs lint + type check)
npm run typecheck  # tsc --noEmit
```

## Make it yours

All content lives in one file: `src/data/portfolio.ts` (profile, nav, hero copy, projects, skills, experience, socials). Everything in it is sample data.

- **Resume:** replace `public/resume.pdf` (currently a placeholder).
- **Project previews:** `src/components/sections/ProjectPreview.tsx` draws placeholder mockups. Swap in real screenshots with `next/image` when ready.
- **Colors:** edit the CSS variables at the top of `src/app/globals.css` (dark values under `:root`, light under `.light`). `tailwind.config.ts` maps them to `background`, `surface`, `border`, `foreground`, `muted`, `accent` and `accent-2`.
- **Contact form:** it posts to `src/app/api/contact/route.ts`, which validates and returns success. Add delivery (Resend, Nodemailer or a webhook) where the TODO is.

## Structure

```
src/
  app/            layout, page, globals.css, api/contact route
  components/
    ui/           Button, Card, Badge, Modal, Reveal, Container, ThemeToggle, icons
    sections/     Navbar, Hero, About, Projects, Skills, Experience, Contact, Footer
  data/portfolio.ts
  hooks/          useActiveSection
  lib/            utils, validation (shared by form and API)
```

## Accessibility notes

Semantic landmarks, skip link, visible focus rings, `aria-current` on the active nav link, labelled form fields with `aria-invalid` and live error messages, focus-trapped modal, and `prefers-reduced-motion` support for all Framer Motion animations.
