import { NextResponse } from "next/server";
import { isContactInput, validateContact } from "@/lib/validation";

export async function POST(request: Request): Promise<NextResponse> {
  const body: unknown = await request.json().catch(() => null);

  if (!isContactInput(body)) {
    return NextResponse.json({ message: "Invalid request." }, { status: 400 });
  }

  const errors = validateContact(body);
  if (Object.keys(errors).length > 0) {
    return NextResponse.json(
      { message: "Please check the form and try again.", errors },
      { status: 422 },
    );
  }

  // TODO: deliver the message. Typical options: Resend, Nodemailer (SMTP),
  // or forward to a Slack / Discord webhook. Keep API keys in .env.local.

  return NextResponse.json({ ok: true });
}
