import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { portfolio } from "@/data/portfolio";

export function About() {
  const { about } = portfolio;

  return (
    <section
      id="about"
      aria-labelledby="about-heading"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <Container>
        <Reveal>
          <SectionHeading id="about-heading" eyebrow="About" title={about.title} />
        </Reveal>

        <div className="mt-12 grid gap-10 lg:grid-cols-5">
          <Reveal className="space-y-5 text-lg leading-relaxed text-muted lg:col-span-3">
            {about.paragraphs.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </Reveal>

          <Reveal delay={0.1} className="lg:col-span-2">
            <Card className="p-6">
              <dl className="space-y-4">
                {about.facts.map((fact) => (
                  <div
                    key={fact.label}
                    className="flex items-baseline justify-between gap-4 border-b border-border pb-3 last:border-0 last:pb-0"
                  >
                    <dt className="text-sm text-muted">{fact.label}</dt>
                    <dd className="text-right text-sm font-medium">{fact.value}</dd>
                  </div>
                ))}
              </dl>

              <div className="mt-6 grid grid-cols-3 gap-4 border-t border-border pt-6">
                {about.stats.map((stat) => (
                  <div key={stat.label}>
                    <p className="bg-gradient-to-r from-accent to-accent-2 bg-clip-text text-3xl font-semibold text-transparent">
                      {stat.value}
                    </p>
                    <p className="mt-1 text-xs text-muted">{stat.label}</p>
                  </div>
                ))}
              </div>
            </Card>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
