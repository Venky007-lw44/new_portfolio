"use client";

import { motion } from "framer-motion";
import {
  Braces,
  Brain,
  Database,
  Layers,
  Sparkles,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { portfolio, type SkillIcon } from "@/data/portfolio";

const SKILL_ICONS: Record<SkillIcon, LucideIcon> = {
  braces: Braces,
  layers: Layers,
  brain: Brain,
  database: Database,
  wrench: Wrench,
  sparkles: Sparkles,
};

export function Skills() {
  return (
    <section
      id="skills"
      aria-labelledby="skills-heading"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <Container>
        <Reveal>
          <SectionHeading
            id="skills-heading"
            eyebrow="Toolbox"
            title="Skills and tech stack"
            description="The languages, frameworks and tools I reach for most often."
          />
        </Reveal>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {portfolio.skills.map((category, index) => {
            const Icon = SKILL_ICONS[category.icon];
            return (
              <Reveal key={category.name} delay={(index % 3) * 0.08} className="h-full">
                <Card className="h-full p-6">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-accent/30 bg-accent/10 text-accent">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <h3 className="text-lg font-semibold tracking-tight">
                      {category.name}
                    </h3>
                  </div>

                  <ul
                    aria-label={`${category.name} skills`}
                    className="mt-5 flex flex-wrap gap-2"
                  >
                    {category.skills.map((skill) => (
                      <motion.li
                        key={skill}
                        whileHover={{ y: -3 }}
                        transition={{ type: "spring", stiffness: 400, damping: 20 }}
                        className="rounded-full border border-border bg-foreground/5 px-3 py-1.5 text-sm text-muted transition-colors hover:border-accent/50 hover:text-foreground"
                      >
                        {skill}
                      </motion.li>
                    ))}
                  </ul>
                </Card>
              </Reveal>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
