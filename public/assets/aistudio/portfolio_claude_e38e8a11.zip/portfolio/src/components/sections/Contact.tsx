"use client";

import {
  ArrowUpRight,
  Check,
  CircleAlert,
  LoaderCircle,
  Mail,
  MapPin,
  Send,
  type LucideIcon,
} from "lucide-react";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { GithubIcon, LinkedinIcon, XIcon } from "@/components/ui/icons";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { portfolio, type SocialPlatform } from "@/data/portfolio";
import { cn } from "@/lib/utils";
import {
  CONTACT_FIELDS,
  MESSAGE_MAX,
  validateContact,
  validateField,
  type ContactErrors,
  type ContactField,
  type ContactInput,
} from "@/lib/validation";

type IconComponent = LucideIcon | typeof GithubIcon;
type Status = "idle" | "submitting" | "success" | "error";

const SOCIAL_ICONS: Record<SocialPlatform, IconComponent> = {
  github: GithubIcon,
  linkedin: LinkedinIcon,
  twitter: XIcon,
  email: Mail,
};

const INITIAL_VALUES: ContactInput = { name: "", email: "", message: "" };

const FALLBACK_ERROR =
  "Something went wrong while sending your message. Please try again.";

function readMessage(data: unknown): string {
  if (typeof data === "object" && data !== null && "message" in data) {
    const message = (data as Record<string, unknown>).message;
    if (typeof message === "string") return message;
  }
  return FALLBACK_ERROR;
}

interface FieldProps {
  name: ContactField;
  label: string;
  value: string;
  error?: string;
  disabled: boolean;
  multiline?: boolean;
  type?: "text" | "email";
  autoComplete?: string;
  placeholder?: string;
  onChange: (name: ContactField, value: string) => void;
  onBlur: (name: ContactField) => void;
}

function Field({
  name,
  label,
  value,
  error,
  disabled,
  multiline = false,
  type = "text",
  autoComplete,
  placeholder,
  onChange,
  onBlur,
}: FieldProps) {
  const id = `contact-${name}`;
  const errorId = `${id}-error`;

  const shared = {
    id,
    name,
    value,
    disabled,
    placeholder,
    autoComplete,
    "aria-required": true,
    "aria-invalid": error ? true : undefined,
    "aria-describedby": error ? errorId : undefined,
    onBlur: () => onBlur(name),
    className: cn(
      "w-full rounded-xl border bg-background/60 px-4 py-3 text-foreground transition-colors placeholder:text-muted/80 focus-visible:outline-none focus-visible:ring-2 disabled:opacity-60",
      error
        ? "border-red-400 focus-visible:ring-red-400/40"
        : "border-border focus-visible:border-accent focus-visible:ring-accent/40",
    ),
  };

  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium">
        {label}
      </label>
      {multiline ? (
        <textarea
          {...shared}
          rows={5}
          maxLength={MESSAGE_MAX + 200}
          onChange={(event) => onChange(name, event.target.value)}
          className={cn(shared.className, "resize-y")}
        />
      ) : (
        <input
          {...shared}
          type={type}
          onChange={(event) => onChange(name, event.target.value)}
        />
      )}
      {error && (
        <p id={errorId} className="mt-2 flex items-center gap-1.5 text-sm text-red-400">
          <CircleAlert className="h-4 w-4 shrink-0" aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  );
}

export function Contact() {
  const { profile, socials } = portfolio;
  const [values, setValues] = useState<ContactInput>(INITIAL_VALUES);
  const [errors, setErrors] = useState<ContactErrors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [serverMessage, setServerMessage] = useState("");

  const isSubmitting = status === "submitting";

  const handleChange = (field: ContactField, value: string) => {
    setValues((current) => ({ ...current, [field]: value }));
    // Clear a field's error as soon as the visitor starts correcting it.
    if (errors[field]) setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const handleBlur = (field: ContactField) => {
    if (values[field] === "") return;
    setErrors((current) => ({ ...current, [field]: validateField(field, values[field]) }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;

    const nextErrors = validateContact(values);
    setErrors(nextErrors);

    const firstInvalid = CONTACT_FIELDS.find((field) => nextErrors[field]);
    if (firstInvalid) {
      const element = form.elements.namedItem(firstInvalid);
      if (element instanceof HTMLElement) element.focus();
      return;
    }

    setStatus("submitting");
    setServerMessage("");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        const data: unknown = await response.json().catch(() => null);
        throw new Error(readMessage(data));
      }

      setValues(INITIAL_VALUES);
      setStatus("success");
    } catch (error) {
      setServerMessage(error instanceof Error ? error.message : FALLBACK_ERROR);
      setStatus("error");
    }
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <Container>
        <div className="grid gap-12 lg:grid-cols-5">
          <Reveal className="lg:col-span-2">
            <SectionHeading
              id="contact-heading"
              eyebrow="Contact"
              title="Let us build something together"
              description="Have a project, a role or just an idea? Send a message and I will get back to you within a couple of days."
            />

            <dl className="mt-8 space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <dt className="sr-only">Email</dt>
                <Mail className="h-4 w-4 text-accent" aria-hidden="true" />
                <dd>
                  <a
                    href={`mailto:${profile.email}`}
                    className="rounded text-muted underline-offset-4 transition-colors hover:text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                  >
                    {profile.email}
                  </a>
                </dd>
              </div>
              <div className="flex items-center gap-3">
                <dt className="sr-only">Location</dt>
                <MapPin className="h-4 w-4 text-accent" aria-hidden="true" />
                <dd className="text-muted">{profile.location}</dd>
              </div>
            </dl>

            <ul aria-label="Social links" className="mt-8 flex flex-wrap gap-3">
              {socials.map((social) => {
                const Icon = SOCIAL_ICONS[social.platform];
                const isExternal = social.platform !== "email";
                return (
                  <li key={social.platform}>
                    <a
                      href={social.href}
                      aria-label={isExternal ? `${social.label} (opens in a new tab)` : social.label}
                      title={social.label}
                      {...(isExternal ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      className="group inline-flex h-11 w-11 items-center justify-center rounded-full border border-border bg-surface/60 text-muted backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:border-accent/50 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                    >
                      <Icon className="h-[18px] w-[18px]" aria-hidden="true" />
                    </a>
                  </li>
                );
              })}
            </ul>
          </Reveal>

          <Reveal delay={0.1} className="lg:col-span-3">
            <Card className="p-6 sm:p-8" spotlight={false}>
              {status === "success" ? (
                <div role="status" className="flex flex-col items-start gap-4 py-6">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-emerald-400/30 bg-emerald-400/10 text-emerald-400">
                    <Check className="h-6 w-6" aria-hidden="true" />
                  </span>
                  <h3 className="text-2xl font-semibold tracking-tight">Message sent</h3>
                  <p className="text-muted">
                    Thanks for reaching out. I will reply to you by email soon.
                  </p>
                  <Button variant="secondary" size="sm" onClick={() => setStatus("idle")}>
                    Send another message
                    <ArrowUpRight className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <p className="text-sm text-muted">All fields are required.</p>

                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field
                      name="name"
                      label="Name"
                      value={values.name}
                      error={errors.name}
                      disabled={isSubmitting}
                      autoComplete="name"
                      placeholder="Your name"
                      onChange={handleChange}
                      onBlur={handleBlur}
                    />
                    <Field
                      name="email"
                      label="Email"
                      type="email"
                      value={values.email}
                      error={errors.email}
                      disabled={isSubmitting}
                      autoComplete="email"
                      placeholder="you@example.com"
                      onChange={handleChange}
                      onBlur={handleBlur}
                    />
                  </div>

                  <Field
                    name="message"
                    label="Message"
                    multiline
                    value={values.message}
                    error={errors.message}
                    disabled={isSubmitting}
                    placeholder="Tell me about your project..."
                    onChange={handleChange}
                    onBlur={handleBlur}
                  />

                  {status === "error" && (
                    <p
                      role="alert"
                      className="flex items-start gap-2 rounded-xl border border-red-400/30 bg-red-400/10 p-3 text-sm text-red-400"
                    >
                      <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                      {serverMessage}
                    </p>
                  )}

                  <Button type="submit" size="lg" disabled={isSubmitting} aria-busy={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" />
                        Sending...
                      </>
                    ) : (
                      <>
                        Send message
                        <Send className="h-4 w-4" aria-hidden="true" />
                      </>
                    )}
                  </Button>
                </form>
              )}
            </Card>
          </Reveal>
        </div>
      </Container>
    </section>
  );
}
