import { ArrowUp } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { portfolio } from "@/data/portfolio";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border py-10">
      <Container className="flex flex-col items-center justify-between gap-4 text-sm text-muted sm:flex-row">
        <p>
          &copy; {year} {portfolio.profile.name}. All rights reserved.
        </p>
        <p>Built with Next.js &amp; Tailwind CSS</p>
        <a
          href="#home"
          className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
        >
          Back to top
          <ArrowUp className="h-4 w-4" aria-hidden="true" />
        </a>
      </Container>
    </footer>
  );
}
