"use client";

import { motion, type Variants } from "framer-motion";
import { ArrowDown, Braces, Brain, Mail, Sparkles, type LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { ButtonLink } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { portfolio, type DomainIcon } from "@/data/portfolio";

const { profile, hero } = portfolio;

const DOMAIN_ICONS: Record<DomainIcon, LucideIcon> = {
  code: Braces,
  brain: Brain,
  sparkles: Sparkles,
};

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.1 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 20 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
};

export function Hero() {
  return (
    <section
      id="home"
      aria-labelledby="hero-heading"
      className="relative flex min-h-[100svh] items-center overflow-hidden pb-20 pt-32"
    >
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="bg-grid absolute inset-0" />
        <div className="absolute -top-32 left-1/2 h-[28rem] w-[28rem] -translate-x-[85%] rounded-full bg-accent/25 blur-[120px] motion-safe:animate-float" />
        <div className="absolute left-1/2 top-40 h-[24rem] w-[24rem] translate-x-[10%] rounded-full bg-accent-2/20 blur-[120px] [animation-delay:-4s] motion-safe:animate-float" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />
      </div>

      <Container className="relative">
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="max-w-4xl"
        >
          <motion.div variants={item}>
            <Badge variant="outline" className="gap-2.5 bg-surface/60 pl-2.5 backdrop-blur-md">
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 motion-safe:animate-ping" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              {profile.availability}
            </Badge>
          </motion.div>

          <motion.h1
            id="hero-heading"
            variants={item}
            className="mt-6 text-balance text-4xl font-semibold tracking-tight sm:text-6xl lg:text-7xl"
          >
            {hero.headline.lead}{" "}
            <span className="bg-gradient-to-r from-accent to-accent-2 bg-clip-text text-transparent">
              {hero.headline.highlight}
            </span>{" "}
            {hero.headline.tail}
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-6 max-w-2xl text-lg leading-relaxed text-muted sm:text-xl"
          >
            {hero.subheading}
          </motion.p>

          <motion.div variants={item} className="mt-9 flex flex-wrap items-center gap-3">
            <ButtonLink href="#projects" size="lg">
              View Projects
              <ArrowDown className="h-4 w-4 transition-transform duration-300 group-hover:translate-y-0.5" />
            </ButtonLink>
            <ButtonLink href="#contact" variant="secondary" size="lg">
              <Mail className="h-4 w-4" />
              Get in Touch
            </ButtonLink>
          </motion.div>

          <motion.ul
            variants={item}
            aria-label="Core domains"
            className="mt-10 flex flex-wrap gap-2"
          >
            {hero.domains.map((domain) => {
              const Icon = DOMAIN_ICONS[domain.icon];
              return (
                <li key={domain.label}>
                  <Badge
                    variant="accent"
                    icon={<Icon className="h-3.5 w-3.5" aria-hidden="true" />}
                  >
                    {domain.label}
                  </Badge>
                </li>
              );
            })}
          </motion.ul>
        </motion.div>
      </Container>
    </section>
  );
}
