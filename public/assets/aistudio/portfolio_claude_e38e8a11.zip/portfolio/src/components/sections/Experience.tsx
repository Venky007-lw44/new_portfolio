import { MapPin } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { portfolio } from "@/data/portfolio";

export function Experience() {
  return (
    <section
      id="experience"
      aria-labelledby="experience-heading"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <Container>
        <Reveal>
          <SectionHeading
            id="experience-heading"
            eyebrow="Journey"
            title="Experience and milestones"
            description="Where I have worked and what I have shipped along the way."
          />
        </Reveal>

        <ol className="relative mt-12 ml-2 border-l border-border sm:ml-3">
          {portfolio.experience.map((item, index) => (
            <li
              key={`${item.organization}-${item.role}`}
              className="relative pb-10 pl-8 last:pb-0 sm:pl-10"
            >
              <span
                aria-hidden="true"
                className="absolute -left-[6px] top-7 h-3 w-3 rounded-full bg-gradient-to-br from-accent to-accent-2 ring-4 ring-background"
              />
              <Reveal delay={Math.min(index, 3) * 0.06}>
                <Card className="p-6">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-xl font-semibold tracking-tight">
                        {item.role}
                      </h3>
                      <p className="mt-1 text-muted">
                        <span className="font-medium text-foreground">
                          {item.organization}
                        </span>
                        <span className="mx-2" aria-hidden="true">
                          /
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                          {item.location}
                        </span>
                      </p>
                    </div>
                    <Badge variant="accent">{item.period}</Badge>
                  </div>

                  <ul className="mt-5 space-y-2 text-sm leading-relaxed text-muted">
                    {item.impact.map((point) => (
                      <li key={point} className="flex gap-3">
                        <span
                          aria-hidden="true"
                          className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent"
                        />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>

                  <ul aria-label="Technologies used" className="mt-5 flex flex-wrap gap-2">
                    {item.stack.map((tech) => (
                      <li key={tech}>
                        <Badge>{tech}</Badge>
                      </li>
                    ))}
                  </ul>
                </Card>
              </Reveal>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}
