"use client";

import { ArrowUpRight, ExternalLink, Star } from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/Badge";
import { ButtonLink } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Container } from "@/components/ui/Container";
import { GithubIcon } from "@/components/ui/icons";
import { Modal } from "@/components/ui/Modal";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { portfolio, type Project } from "@/data/portfolio";
import { cn } from "@/lib/utils";
import { ProjectPreview } from "./ProjectPreview";

/**
 * Bento placement by position (featured project first):
 * lg (4 cols): featured = 2x2, 2nd = wide, 3rd and 4th = single cells.
 * md (2 cols): featured spans the row, last card spans the row.
 */
const GRID_SLOTS: readonly string[] = [
  "md:col-span-2 lg:row-span-2",
  "lg:col-span-2",
  "",
  "md:col-span-2 lg:col-span-1",
];

interface ProjectCardProps {
  project: Project;
  className?: string;
  onOpenDetails: (project: Project) => void;
}

function ProjectCard({ project, className, onOpenDetails }: ProjectCardProps) {
  const featured = project.featured === true;

  return (
    <Reveal className={cn("h-full", className)}>
      <Card className="h-full">
        <ProjectPreview kind={project.preview} featured={featured} />

        <div className={cn("flex flex-col gap-4 p-6", !featured && "flex-1")}>
          <div>
            {featured && (
              <Badge
                variant="accent"
                className="mb-3"
                icon={<Star className="h-3 w-3" aria-hidden="true" />}
              >
                Featured
              </Badge>
            )}
            <h3
              className={cn(
                "font-semibold tracking-tight",
                featured ? "text-2xl" : "text-xl",
              )}
            >
              {project.title}
            </h3>
            <p className="mt-2 leading-relaxed text-muted">{project.description}</p>
          </div>

          <ul aria-label={`${project.title} tech stack`} className="flex flex-wrap gap-2">
            {project.tags.map((tag) => (
              <li key={tag}>
                <Badge>{tag}</Badge>
              </li>
            ))}
          </ul>

          <div className="mt-auto flex flex-wrap items-center gap-3 pt-2">
            <ButtonLink
              href={project.githubUrl}
              external
              size="sm"
              variant="secondary"
              aria-label={`${project.title} on GitHub (opens in a new tab)`}
            >
              <GithubIcon className="h-4 w-4" />
              GitHub
              <ExternalLink className="h-3.5 w-3.5 opacity-70" />
            </ButtonLink>
            <ButtonLink
              href={project.liveUrl}
              external
              size="sm"
              aria-label={`${project.title} live demo (opens in a new tab)`}
            >
              Live Demo
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </ButtonLink>
            <button
              type="button"
              onClick={() => onOpenDetails(project)}
              aria-label={`Read more about ${project.title}`}
              className="ml-auto rounded-full px-2 py-1 text-sm text-muted underline-offset-4 transition-colors hover:text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
            >
              Details
            </button>
          </div>
        </div>
      </Card>
    </Reveal>
  );
}

export function Projects() {
  const [selected, setSelected] = useState<Project | null>(null);

  return (
    <section
      id="projects"
      aria-labelledby="projects-heading"
      className="relative scroll-mt-24 py-24 sm:py-32"
    >
      <Container>
        <Reveal>
          <SectionHeading
            id="projects-heading"
            eyebrow="Selected work"
            title="Featured projects"
            description="A few things I have built recently, from AI tooling to creative experiments."
          />
        </Reveal>

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {portfolio.projects.map((project, index) => (
            <ProjectCard
              key={project.id}
              project={project}
              className={GRID_SLOTS[index]}
              onOpenDetails={setSelected}
            />
          ))}
        </div>
      </Container>

      <Modal
        open={selected !== null}
        onClose={() => setSelected(null)}
        title={selected?.title ?? ""}
        description={selected?.description}
      >
        {selected && (
          <div className="space-y-6">
            <p className="leading-relaxed text-muted">{selected.details}</p>

            <div>
              <h4 className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-accent">
                Highlights
              </h4>
              <ul className="space-y-2 text-sm">
                {selected.highlights.map((highlight) => (
                  <li key={highlight} className="flex gap-3">
                    <span
                      aria-hidden="true"
                      className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-gradient-to-r from-accent to-accent-2"
                    />
                    <span>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>

            <ul aria-label="Tech stack" className="flex flex-wrap gap-2">
              {selected.tags.map((tag) => (
                <li key={tag}>
                  <Badge>{tag}</Badge>
                </li>
              ))}
            </ul>

            <div className="flex flex-wrap gap-3">
              <ButtonLink href={selected.githubUrl} external size="sm" variant="secondary">
                <GithubIcon className="h-4 w-4" />
                GitHub
                <ExternalLink className="h-3.5 w-3.5 opacity-70" />
              </ButtonLink>
              <ButtonLink href={selected.liveUrl} external size="sm">
                Live Demo
                <ArrowUpRight className="h-4 w-4" />
              </ButtonLink>
            </div>
          </div>
        )}
      </Modal>
    </section>
  );
}
