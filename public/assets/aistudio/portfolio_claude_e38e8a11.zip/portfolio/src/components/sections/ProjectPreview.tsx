import type { ProjectPreviewKind } from "@/data/portfolio";
import { cn } from "@/lib/utils";

const BARS: readonly number[] = [38, 62, 48, 78, 58, 90, 70, 84];
const RINGS: readonly number[] = [220, 160, 105, 56];

interface ProjectPreviewProps {
  kind: ProjectPreviewKind;
  featured?: boolean;
}

/** Decorative placeholder mockup. Swap for real screenshots when you have them. */
export function ProjectPreview({ kind, featured = false }: ProjectPreviewProps) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        "relative isolate shrink-0 overflow-hidden border-b border-border bg-gradient-to-br from-accent/20 via-transparent to-accent-2/20",
        featured ? "min-h-[16rem] flex-1" : "h-40",
      )}
    >
      <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/30 blur-3xl" />

      <div className="absolute inset-x-6 bottom-0 top-6 overflow-hidden rounded-t-xl border border-b-0 border-border bg-background/70 shadow-2xl backdrop-blur-sm">
        <div className="flex h-8 items-center gap-1.5 border-b border-border px-3">
          <span className="h-2 w-2 rounded-full bg-foreground/20" />
          <span className="h-2 w-2 rounded-full bg-foreground/20" />
          <span className="h-2 w-2 rounded-full bg-foreground/20" />
        </div>

        <div className="absolute inset-x-0 bottom-0 top-8">
          {kind === "chart" && (
            <div className="flex h-full items-end gap-2 p-4">
              {BARS.map((height, index) => (
                <div
                  key={index}
                  style={{ height: `${height}%` }}
                  className="flex-1 rounded-t bg-gradient-to-t from-accent/70 to-accent-2/70"
                />
              ))}
            </div>
          )}

          {kind === "chat" && (
            <div className="flex h-full flex-col justify-end gap-3 p-4">
              <div className="h-3 w-2/3 rounded-full bg-foreground/10" />
              <div className="ml-auto h-8 w-1/2 rounded-2xl rounded-br-sm bg-gradient-to-r from-accent/70 to-accent-2/70" />
              <div className="space-y-2 rounded-2xl rounded-bl-sm bg-foreground/5 p-3">
                <div className="h-2 w-full rounded-full bg-foreground/15" />
                <div className="h-2 w-5/6 rounded-full bg-foreground/15" />
                <div className="h-2 w-2/3 rounded-full bg-foreground/15" />
              </div>
              <div className="flex items-center gap-2 rounded-full border border-border px-3 py-2">
                <div className="h-2 flex-1 rounded-full bg-foreground/10" />
                <div className="h-5 w-5 rounded-full bg-accent/80" />
              </div>
            </div>
          )}

          {kind === "canvas" && (
            <div className="relative flex h-full items-center justify-center overflow-hidden">
              {RINGS.map((size) => (
                <div
                  key={size}
                  style={{ width: size, height: size }}
                  className="absolute rounded-full border border-accent/40"
                />
              ))}
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-accent to-accent-2 blur-md" />
            </div>
          )}

          {kind === "terminal" && (
            <div className="space-y-2 p-4 font-mono text-xs">
              <p className="text-accent">$ forge init my-service</p>
              <p className="text-muted">scaffolding project...</p>
              <p className="text-muted">linting, tests and CI configured</p>
              <p className="text-accent-2">ready in 42s</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
