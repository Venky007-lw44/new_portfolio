interface SectionHeadingProps {
  id: string;
  eyebrow: string;
  title: string;
  description?: string;
}

export function SectionHeading({
  id,
  eyebrow,
  title,
  description,
}: SectionHeadingProps) {
  return (
    <div className="max-w-2xl">
      <p className="mb-3 inline-flex items-center gap-3 font-mono text-xs uppercase tracking-[0.2em] text-accent">
        <span
          aria-hidden="true"
          className="h-px w-8 bg-gradient-to-r from-accent to-accent-2"
        />
        {eyebrow}
      </p>
      <h2
        id={id}
        className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl"
      >
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-lg leading-relaxed text-muted">{description}</p>
      )}
    </div>
  );
}
