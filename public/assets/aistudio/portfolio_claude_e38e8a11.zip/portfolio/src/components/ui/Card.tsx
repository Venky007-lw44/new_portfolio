"use client";

import { useCallback, useRef, type HTMLAttributes, type MouseEvent } from "react";
import { cn } from "@/lib/utils";

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** Cursor-following glow on hover. */
  spotlight?: boolean;
}

export function Card({
  className,
  children,
  spotlight = true,
  ...rest
}: CardProps) {
  const ref = useRef<HTMLDivElement>(null);

  const handleMouseMove = useCallback((event: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${event.clientX - rect.left}px`);
    el.style.setProperty("--my", `${event.clientY - rect.top}px`);
  }, []);

  return (
    <div
      ref={ref}
      onMouseMove={spotlight ? handleMouseMove : undefined}
      className={cn(
        "group relative overflow-hidden rounded-2xl border border-border bg-surface/60 backdrop-blur-md transition-colors duration-300 hover:border-accent/40",
        className,
      )}
      {...rest}
    >
      {spotlight && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          style={{
            background:
              "radial-gradient(420px circle at var(--mx, 50%) var(--my, 50%), rgb(var(--accent) / 0.14), transparent 60%)",
          }}
        />
      )}
      <div className="relative flex h-full flex-col">{children}</div>
    </div>
  );
}
