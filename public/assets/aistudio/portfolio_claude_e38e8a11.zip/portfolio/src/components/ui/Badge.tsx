import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

export type BadgeVariant = "neutral" | "accent" | "outline";

export interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  icon?: ReactNode;
}

const variants: Record<BadgeVariant, string> = {
  neutral: "border-border bg-foreground/5 text-muted",
  accent: "border-accent/30 bg-accent/10 text-accent",
  outline: "border-border bg-transparent text-muted",
};

export function Badge({
  variant = "neutral",
  icon,
  className,
  children,
  ...rest
}: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium",
        variants[variant],
        className,
      )}
      {...rest}
    >
      {icon}
      {children}
    </span>
  );
}
