import type { AnchorHTMLAttributes, ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export type ButtonVariant = "primary" | "secondary" | "ghost";
export type ButtonSize = "sm" | "md" | "lg";

interface StyleProps {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

const base =
  "group relative inline-flex select-none items-center justify-center gap-2 rounded-full font-medium transition-all duration-300 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-60";

const variants: Record<ButtonVariant, string> = {
  primary:
    "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-glow hover:-translate-y-0.5 hover:shadow-glow-lg active:translate-y-0",
  secondary:
    "border border-border bg-surface/60 text-foreground backdrop-blur-md hover:-translate-y-0.5 hover:border-accent/50 hover:bg-surface active:translate-y-0",
  ghost: "text-muted hover:bg-foreground/5 hover:text-foreground",
};

const sizes: Record<ButtonSize, string> = {
  sm: "h-9 px-4 text-sm",
  md: "h-11 px-6 text-sm",
  lg: "h-12 px-7 text-base",
};

export function buttonStyles({
  variant = "primary",
  size = "md",
  className,
}: StyleProps & { className?: string }): string {
  return cn(base, variants[variant], sizes[size], className);
}

type ButtonProps = StyleProps & ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({
  variant,
  size,
  className,
  type = "button",
  ...rest
}: ButtonProps) {
  return (
    <button
      type={type}
      className={buttonStyles({ variant, size, className })}
      {...rest}
    />
  );
}

type ButtonLinkProps = StyleProps &
  AnchorHTMLAttributes<HTMLAnchorElement> & {
    /** Opens in a new tab with a safe `rel`. */
    external?: boolean;
  };

export function ButtonLink({
  variant,
  size,
  className,
  external = false,
  ...rest
}: ButtonLinkProps) {
  const externalProps = external
    ? { target: "_blank", rel: "noopener noreferrer" }
    : {};

  return (
    <a
      className={buttonStyles({ variant, size, className })}
      {...externalProps}
      {...rest}
    />
  );
}
