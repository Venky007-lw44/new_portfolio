/**
 * Single source of truth for all portfolio content.
 * Everything below is SAMPLE DATA: replace it with your own details.
 */

export type SocialPlatform = "github" | "linkedin" | "twitter" | "email";
export type DomainIcon = "code" | "brain" | "sparkles";
export type SkillIcon =
  | "braces"
  | "layers"
  | "brain"
  | "database"
  | "wrench"
  | "sparkles";
export type ProjectPreviewKind = "chat" | "chart" | "canvas" | "terminal";

export interface Profile {
  name: string;
  initials: string;
  role: string;
  location: string;
  email: string;
  siteUrl: string;
  resumeUrl: string;
  availability: string;
  description: string;
}

export interface NavItem {
  label: string;
  href: `#${string}`;
}

export interface Domain {
  label: string;
  icon: DomainIcon;
}

export interface HeroContent {
  headline: { lead: string; highlight: string; tail: string };
  subheading: string;
  domains: Domain[];
}

export interface AboutContent {
  title: string;
  paragraphs: string[];
  facts: { label: string; value: string }[];
  stats: { value: string; label: string }[];
}

export interface Project {
  id: string;
  title: string;
  description: string;
  details: string;
  highlights: string[];
  tags: string[];
  githubUrl: string;
  liveUrl: string;
  preview: ProjectPreviewKind;
  featured?: boolean;
}

export interface SkillCategory {
  name: string;
  icon: SkillIcon;
  skills: string[];
}

export interface ExperienceItem {
  role: string;
  organization: string;
  period: string;
  location: string;
  impact: string[];
  stack: string[];
}

export interface SocialLink {
  platform: SocialPlatform;
  label: string;
  handle: string;
  href: string;
}

export interface Portfolio {
  profile: Profile;
  nav: NavItem[];
  hero: HeroContent;
  about: AboutContent;
  /** Keep the featured project first: the bento grid gives it the large slot. */
  projects: Project[];
  skills: SkillCategory[];
  experience: ExperienceItem[];
  socials: SocialLink[];
}

export const portfolio: Portfolio = {
  profile: {
    name: "Alex Morgan",
    initials: "AM",
    role: "Full-Stack & AI Engineer",
    location: "Bengaluru, India",
    email: "hello@example.com",
    siteUrl: "https://example.com",
    resumeUrl: "/resume.pdf",
    availability: "Open to new opportunities",
    description:
      "Portfolio of Alex Morgan, a full-stack engineer building AI-powered products and creative web experiences.",
  },

  nav: [
    { label: "About", href: "#about" },
    { label: "Projects", href: "#projects" },
    { label: "Skills", href: "#skills" },
    { label: "Experience", href: "#experience" },
    { label: "Contact", href: "#contact" },
  ],

  hero: {
    headline: {
      lead: "I design and build",
      highlight: "intelligent, beautiful",
      tail: "software for the web.",
    },
    subheading:
      "Full-stack engineer specialising in AI-powered products and creative web experiences. I care about craft, performance and the small details that make software feel alive.",
    domains: [
      { label: "Full-Stack Dev", icon: "code" },
      { label: "AI & ML", icon: "brain" },
      { label: "Creative Tech", icon: "sparkles" },
    ],
  },

  about: {
    title: "Engineering with an eye for detail",
    paragraphs: [
      "I am a software engineer who enjoys the full journey from a rough idea to a polished product: shaping the data model, wiring up the APIs, training or prompting the models, and sweating the last pixel of the interface.",
      "Over the past six years I have shipped products across fintech, developer tooling and applied AI. I am happiest on small, senior teams where design, engineering and research sit close together.",
      "Away from the keyboard you will find me sketching generative art, tinkering with open-source side projects, or hunting for the best filter coffee in town.",
    ],
    facts: [
      { label: "Based in", value: "Bengaluru, India" },
      { label: "Focus", value: "Full-stack, applied AI" },
      { label: "Currently", value: "Building LLM-powered tools" },
      { label: "Languages", value: "English, Hindi, Telugu" },
    ],
    stats: [
      { value: "6+", label: "Years building" },
      { value: "30+", label: "Projects shipped" },
      { value: "12", label: "OSS contributions" },
    ],
  },

  projects: [
    {
      id: "lumen",
      title: "Lumen: AI Research Copilot",
      description:
        "A retrieval-augmented research assistant that reads your papers, cites its sources and drafts literature reviews in minutes.",
      details:
        "Lumen indexes PDFs and web sources into a hybrid search layer, then streams grounded answers with inline citations. It was built to make literature reviews faster without sacrificing traceability: every claim links back to the passage it came from.",
      highlights: [
        "Hybrid retrieval (BM25 + vector search) to keep answers grounded",
        "Streaming responses with clickable inline citations",
        "Background ingestion pipeline for large PDF collections",
      ],
      tags: ["Next.js", "TypeScript", "FastAPI", "pgvector", "OpenAI"],
      githubUrl: "https://github.com/your-handle/lumen",
      liveUrl: "https://lumen.example.com",
      preview: "chat",
      featured: true,
    },
    {
      id: "pulse",
      title: "Pulse: Realtime Analytics",
      description:
        "A low-latency analytics dashboard that streams product events and surfaces anomalies as they happen.",
      details:
        "Pulse ingests event streams over WebSockets, aggregates them in ClickHouse and renders live charts with sub-second updates. Alerting rules flag anomalies before they reach a customer.",
      highlights: [
        "Sub-second chart updates over WebSockets",
        "Rule-based anomaly alerts with Slack delivery",
        "Role-based dashboards and shareable views",
      ],
      tags: ["React", "Go", "ClickHouse", "WebSockets"],
      githubUrl: "https://github.com/your-handle/pulse",
      liveUrl: "https://pulse.example.com",
      preview: "chart",
    },
    {
      id: "aurora",
      title: "Aurora: Generative Art Studio",
      description:
        "A browser playground for shader-driven generative art with shareable presets.",
      details:
        "Aurora lets you compose GLSL shaders with live parameter controls, then export stills or share a link to the exact preset. It is a sandbox for creative-coding experiments.",
      highlights: [
        "Live-editable GLSL with parameter sliders",
        "Shareable preset URLs",
        "High-resolution PNG export",
      ],
      tags: ["Three.js", "GLSL", "WebGL"],
      githubUrl: "https://github.com/your-handle/aurora",
      liveUrl: "https://aurora.example.com",
      preview: "canvas",
    },
    {
      id: "forge",
      title: "Forge CLI",
      description:
        "A zero-config scaffolding tool that bootstraps production-ready TypeScript services.",
      details:
        "Forge generates opinionated service templates with linting, testing, CI and Docker already wired up, so a new project is deployable in a couple of minutes.",
      highlights: [
        "Interactive prompts with sensible defaults",
        "Pluggable template system",
        "Ships with CI and container config",
      ],
      tags: ["Node.js", "TypeScript", "Vitest"],
      githubUrl: "https://github.com/your-handle/forge",
      liveUrl: "https://forge.example.com",
      preview: "terminal",
    },
  ],

  skills: [
    {
      name: "Languages",
      icon: "braces",
      skills: ["TypeScript", "Python", "Go", "SQL", "Rust", "C++"],
    },
    {
      name: "Frameworks",
      icon: "layers",
      skills: [
        "Next.js",
        "React",
        "Node.js",
        "FastAPI",
        "Tailwind CSS",
        "Framer Motion",
      ],
    },
    {
      name: "AI & ML",
      icon: "brain",
      skills: [
        "PyTorch",
        "LangChain",
        "OpenAI API",
        "Hugging Face",
        "scikit-learn",
        "RAG pipelines",
      ],
    },
    {
      name: "Databases",
      icon: "database",
      skills: ["PostgreSQL", "pgvector", "Redis", "MongoDB", "ClickHouse", "Prisma"],
    },
    {
      name: "Tools & Cloud",
      icon: "wrench",
      skills: ["Docker", "AWS", "Vercel", "Git", "GitHub Actions", "Figma"],
    },
    {
      name: "Creative Tech",
      icon: "sparkles",
      skills: ["Three.js", "WebGL", "GLSL", "Canvas API", "p5.js", "Blender"],
    },
  ],

  experience: [
    {
      role: "Senior Software Engineer",
      organization: "Northwind Labs",
      period: "2024 - Present",
      location: "Remote",
      impact: [
        "Led the design of an LLM-powered assistant used by 40,000+ monthly users.",
        "Cut median API latency by 45% by reworking caching and query paths.",
        "Mentored four engineers and introduced a lightweight design-review process.",
      ],
      stack: ["Next.js", "Python", "PostgreSQL", "AWS"],
    },
    {
      role: "Machine Learning Engineer",
      organization: "Helix AI",
      period: "2022 - 2024",
      location: "Bengaluru",
      impact: [
        "Shipped a document-classification service that automated 70% of manual review.",
        "Built the evaluation harness the team still uses to compare model releases.",
        "Reduced inference cost by 30% through batching and quantisation.",
      ],
      stack: ["PyTorch", "FastAPI", "Docker", "Redis"],
    },
    {
      role: "Frontend Engineer",
      organization: "Pixel & Co",
      period: "2020 - 2022",
      location: "Hyderabad",
      impact: [
        "Built a React component library adopted across five product teams.",
        "Improved Lighthouse performance scores from 62 to 95 on core pages.",
        "Partnered with design to prototype and ship interactive marketing sites.",
      ],
      stack: ["React", "TypeScript", "Storybook", "Three.js"],
    },
    {
      role: "B.Tech, Computer Science",
      organization: "Example Institute of Technology",
      period: "2016 - 2020",
      location: "India",
      impact: [
        "Graduated with distinction; focus on machine learning and distributed systems.",
        "Led the university creative-coding club.",
      ],
      stack: ["C++", "Python"],
    },
  ],

  socials: [
    {
      platform: "github",
      label: "GitHub",
      handle: "@your-handle",
      href: "https://github.com/your-handle",
    },
    {
      platform: "linkedin",
      label: "LinkedIn",
      handle: "in/your-handle",
      href: "https://www.linkedin.com/in/your-handle",
    },
    {
      platform: "twitter",
      label: "Twitter / X",
      handle: "@your_handle",
      href: "https://x.com/your_handle",
    },
    {
      platform: "email",
      label: "Email",
      handle: "hello@example.com",
      href: "mailto:hello@example.com",
    },
  ],
};
