/**
 * Contact-form validation shared by the client form and the API route,
 * so both sides enforce exactly the same rules.
 */

export interface ContactInput {
  name: string;
  email: string;
  message: string;
}

export type ContactField = keyof ContactInput;
export type ContactErrors = Partial<Record<ContactField, string>>;

export const CONTACT_FIELDS: readonly ContactField[] = [
  "name",
  "email",
  "message",
];

export const MESSAGE_MIN = 10;
export const MESSAGE_MAX = 1000;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateField(
  field: ContactField,
  rawValue: string,
): string | undefined {
  const value = rawValue.trim();

  switch (field) {
    case "name":
      if (!value) return "Please enter your name.";
      if (value.length < 2) return "Name must be at least 2 characters.";
      if (value.length > 80) return "Name must be 80 characters or fewer.";
      return undefined;
    case "email":
      if (!value) return "Please enter your email address.";
      if (!EMAIL_PATTERN.test(value)) return "Please enter a valid email address.";
      return undefined;
    case "message":
      if (!value) return "Please write a message.";
      if (value.length < MESSAGE_MIN)
        return `Message must be at least ${MESSAGE_MIN} characters.`;
      if (value.length > MESSAGE_MAX)
        return `Message must be ${MESSAGE_MAX} characters or fewer.`;
      return undefined;
  }
}

export function validateContact(input: ContactInput): ContactErrors {
  const errors: ContactErrors = {};
  for (const field of CONTACT_FIELDS) {
    const error = validateField(field, input[field]);
    if (error) errors[field] = error;
  }
  return errors;
}

export function isContactInput(value: unknown): value is ContactInput {
  if (typeof value !== "object" || value === null) return false;
  const record = value as Record<string, unknown>;
  return CONTACT_FIELDS.every((field) => typeof record[field] === "string");
}
