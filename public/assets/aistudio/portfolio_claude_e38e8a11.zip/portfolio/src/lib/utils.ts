export type ClassValue = string | false | null | undefined;

/** Tiny class-name joiner (keeps the dependency list short). */
export function cn(...classes: ClassValue[]): string {
  return classes.filter(Boolean).join(" ");
}
